#ifndef SNAKE_EVENTCONTROL_H
#define SNAKE_EVENTCONTROL_H
#include <SFML/Graphics.hpp>
#include "SnakeBoard.h"

class SnakeBoard;

class EventControl{
SnakeBoard &board;
    double speed;
public:
    explicit EventControl(SnakeBoard &b);
    void keyboardControl(Move &move);
    void mouseControlMain(Where &where, sf::Event event);
    void mouseControlDiff(Where &where, sf::Event event);
};


#endif
