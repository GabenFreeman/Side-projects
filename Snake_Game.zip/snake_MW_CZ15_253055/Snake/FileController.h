#ifndef SNAKE_FILECONTROLLER_H
#define SNAKE_FILECONTROLLER_H
#include <fstream>

class FileController {
    const int size=10;
    int score[10];
    void createBlank();

public:
    FileController();
    void end(int newScore);
    int getScore(int which);
};


#endif
