#include "FileController.h"
#include <iostream>

FileController::FileController()
{
    std::fstream file;
    file.open("../score.txt", std::ios::in);
    if(file.good()== false)
    {
        file.close();
        createBlank();
    }
}

void FileController::createBlank()
{
    std::fstream file;
    file.open("../score.txt", std::ios::out);
    for(int i=0; i<size; i++)
    {
        file<<0<<std::endl;
    }
    file.close();
}

void FileController::end(int newScore)
{
    std::fstream file;
    file.open("../score.txt", std::ios::in);
    int i=0;
    std::string line;
    while(std::getline(file, line))
    {
        score[i]=atoi(line.c_str());
        i++;
    }
    file.close();
    //
    if(newScore>score[9])
    {
        score[9]=newScore;
    }
    for(int i=0; i<size; i++)
    {
        for(int j=0; j<size-1; j++)
        {
            if(score[j]<score[j+1])
                std::swap(score[j],score[j+1]);
        }
    }
    //
    file.open("../score.txt", std::ios::out);
    for(int i=0; i<size; i++)
    {
        file<<score[i]<<std::endl;
    }
    file.close();
}

int FileController::getScore(int which)
{
    return score[which];
}
