#include <cstdlib>
#include <time.h>

#include "Snake.h"
#include "Fruit.h"
#include "TextureLoaderSFML.h"
#include "SnakeBoard.h"
#include "BoardSFML.h"
#include "EventControl.h"
#include "FileController.h"


int main() {
    srand (time(nullptr));
    FileController fileController;
    SnakeBoard board(fileController);
    TextureLoaderSFML textureLoader;
    EventControl eventControl(board);
    BoardSFML boardSfml(board, fileController, textureLoader, eventControl);
    boardSfml.menu();
    return 0;
}
