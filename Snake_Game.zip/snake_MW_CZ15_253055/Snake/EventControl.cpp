#include "EventControl.h"


EventControl::EventControl(SnakeBoard &b) :board(b)
{

}


void EventControl::keyboardControl(Move &move)
{
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)&& move!=RIGHT) move=LEFT;
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)&& move!=LEFT) move=RIGHT;
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)&& move!=DOWN) move=UP;
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down)&& move!=UP) move=DOWN;
}

void EventControl::mouseControlMain(Where &where, sf::Event event)
{
    if(sf::Mouse::isButtonPressed((sf::Mouse::Left))&& where==DIFF)
    {
        mouseControlDiff(where, event);
    }
}

void EventControl::mouseControlDiff(Where &where, sf::Event event)
{
    if(event.mouseButton.x>=(80) && event.mouseButton.x<=(240)&&event.mouseButton.y>=(520) && event.mouseButton.y<=(640))
    {
        where=GAME;
        speed=0.6;
        board.changeSpeed(speed);
    }
    if(event.mouseButton.x>=(280) && event.mouseButton.x<=(520)&&event.mouseButton.y>=(520) && event.mouseButton.y<=(640))
    {
        where=GAME;
        speed=0.40;
        board.changeSpeed(speed);
    }
    if(event.mouseButton.x>=(560) && event.mouseButton.x<=(720)&&event.mouseButton.y>=(520) && event.mouseButton.y<=(640))
    {
        where=GAME;
        speed=0.25;
        board.changeSpeed(speed);
    }
}
