#ifndef SNAKE_BOARDSFML_H
#define SNAKE_BOARDSFML_H

#include "SnakeBoard.h"
#include "TextureLoaderSFML.h"
#include "EventControl.h"

class TextureLoaderSFML;
class EventControl;
class SnakeBoard;

class BoardSFML{
    TextureLoaderSFML & textureLoader;
    EventControl & eventControl;
    FileController & fileController;
    sf::Sprite spriteTlo;
    sf::Sprite sprite;
    sf::Texture texture;
    sf::Font font;
    sf::Text text;
    void location(sf::RenderWindow &win, float & timer, sf::Event event);
    void drawGame(sf::RenderWindow &win, float & timer);
    void drawSnake(sf::RenderWindow &win);
    void drawFruit(sf::RenderWindow &win);
    void drawDiff(sf::RenderWindow &win);
    void drawScore(sf::RenderWindow &win);
public:
    SnakeBoard & board;
    BoardSFML(SnakeBoard &b , FileController &fc, TextureLoaderSFML &tl, EventControl &ec);
    void menu();
};


#endif
