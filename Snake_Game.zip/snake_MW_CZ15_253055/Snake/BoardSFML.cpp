#include "BoardSFML.h"


BoardSFML::BoardSFML(SnakeBoard &b, FileController &fc, TextureLoaderSFML &tl, EventControl &ec): board(b), fileController(fc), textureLoader(tl), eventControl(ec)
{
    textureLoader.loadTexture(texture, 'D');
    spriteTlo.setTexture(texture);
    textureLoader.loadTexture(texture, 'S');
    sprite.setTexture(texture);
    textureLoader.loadVont(font, text);
}


void BoardSFML::menu()
{
    bool isOpen=true;
    float timer=0;
    float time;

    sf::Clock clock;
    sf::RenderWindow win(sf::VideoMode(board.getWidth()*board.getTexSize(), board.getHeight()*board.getTexSize()), "Snake.");//20x20
    win.setVerticalSyncEnabled(true);

    sprite.setPosition(9*board.getTexSize(), 1*board.getTexSize());
    while(isOpen)
    {
        sf::Event event;
        time = clock.getElapsedTime().asSeconds();
        clock.restart();
        timer+=time;
        while(win.pollEvent(event))
        {
            if(event.type==sf::Event::Closed)
            {
                win.close();
                isOpen=false;
            }
        }
        eventControl.keyboardControl(board.move);

        win.clear(sf::Color(179,179,179));
        /////////////////////start draw area!////////////////////////////////
        location(win, timer, event);
        /////////////////////end draw area!//////////////////////////////////
        win.display();
    }
}

void BoardSFML::drawGame(sf::RenderWindow &win, float & timer)
{
    textureLoader.loadTexture(texture, 'G');
    spriteTlo.setTexture(texture);
    win.draw(spriteTlo);
    drawFruit(win);
    textureLoader.loadTexture(texture, 'S');
    sprite.setTexture(texture);
    for(int i=0; i<board.getSnakeLength(); i++)
    {
        sprite.setPosition((board.getSnakeX(i)) * board.getTexSize(), (board.getSnakeY(i)) * board.getTexSize());
        win.draw(sprite);
    }
    if (timer>board.getSpeed())
    {
        timer=0;
        board.update();
        drawSnake(win);
    }
}

void BoardSFML::drawDiff(sf::RenderWindow &win)
{
    textureLoader.loadTexture(texture, 'D');
    spriteTlo.setTexture(texture);
    win.draw(spriteTlo);
}

void BoardSFML::drawScore(sf::RenderWindow &win)
{
    textureLoader.loadTexture(texture, 'E');
    spriteTlo.setTexture(texture);
    win.draw(spriteTlo);
    for(int i=0; i<10; i++)
    {
        std::string x = std::to_string(i+1);
        std::string y = std::to_string(fileController.getScore(i));
        std::string all=x+". "+y;
        text.setPosition(120,i*48+240);
        text.setString(all);
        win.draw(text);
    }
}

void BoardSFML::drawSnake(sf::RenderWindow &win)
{
    for(int i=0; i<board.getSnakeLength(); i++)
    {
        textureLoader.loadTexture(texture, 'S');
        sprite.setTexture(texture);
        sprite.setPosition((board.getSnakeX(i)) * board.getTexSize(), (board.getSnakeY(i)) * board.getTexSize());
        win.draw(sprite);
    }
}

void BoardSFML::drawFruit(sf::RenderWindow &win)
{
    textureLoader.loadTexture(texture, 'F');
    sprite.setTexture(texture);
    sprite.setPosition(board.getFruitX()*board.getTexSize(), board.getFruitY()*board.getTexSize());
    win.draw(sprite);
}

void BoardSFML::location(sf::RenderWindow &win, float & timer, sf::Event event)
{
    if(board.where==DIFF)
    {
        drawDiff(win);
        eventControl.mouseControlMain(board.where, event);
    }
    else if(board.where==GAME)
    {
        drawGame(win, timer);
    }
    else if(board.where==SCORE)
    {
        drawScore(win);
        eventControl.mouseControlMain(board.where, event);
    }
}







