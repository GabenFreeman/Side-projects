#ifndef SNAKE_FRUIT_H
#define SNAKE_FRUIT_H
struct Fruit
{
    int x=2;
    int y=8;
};
#endif
